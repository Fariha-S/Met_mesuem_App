import { useState } from 'react';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';
import Form from 'react-bootstrap/Form';
import FormControl from 'react-bootstrap/FormControl';
import Button from 'react-bootstrap/Button';
import Container from 'react-bootstrap/Container';
import { useAtom } from 'jotai';
import { searchHistoryAtom } from '@/store';


import Link from 'next/link';
import { useRouter } from 'next/router';
import NavDropdown from 'react-bootstrap/NavDropdown';



export default function MainNav() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchField, setSearchField] = useState('');
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

  
  const router = useRouter();

  function submitForm(e) {
    e.preventDefault();
    if (!searchField.trim()) return;
    const queryString = `title=true&q=${searchField}`;
    setSearchHistory(current => [...current, queryString]);
    router.push(`/artwork?title=true&q=${searchField}`);
    setSearchField('');
    setIsExpanded(false);
  }

  return (
    <>
      <Navbar expanded={isExpanded} expand="lg" className="navbar navbar-dark bg-primary fixed-top">

      
        <Container>
          <Navbar.Brand>Fariha Shajjan</Navbar.Brand>
          <Navbar.Toggle
            aria-controls="basic-navbar-nav"
            onClick={() => setIsExpanded(!isExpanded)} 
          />

          <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="me-auto">
            <Link href="/" passHref legacyBehavior>
            <Nav.Link onClick={() => setIsExpanded(false)} active={router.pathname === "/"}>
             Home
            </Nav.Link>
            </Link>

            <Link href="/search" passHref legacyBehavior>
            <Nav.Link onClick={() => setIsExpanded(false)} active={router.pathname === "/search"}>
            Advanced Search
            </Nav.Link>
            </Link>
            </Nav>
            &nbsp;

            <Form className="d-flex" onSubmit={submitForm}>
              <FormControl
                type="search"
                placeholder="Search"
                className="me-2"
                aria-label="Search"
                value={searchField}
                onChange={(e) => setSearchField(e.target.value)}
              />
              <Button variant="success" type="submit">Search</Button>
            </Form>
            &nbsp;
             {/* User dropdown (Favourites) */}
            <Nav>
              <NavDropdown title="User Name" id="basic-nav-dropdown">
                <Link href="/favourites" passHref legacyBehavior>
                  <NavDropdown.Item 
                   onClick={() => setIsExpanded(false)} active={router.pathname === "/favourites"}>
                    Favourites
                  </NavDropdown.Item>
                  </Link>

                <Link href="/history" passHref legacyBehavior>
                  <NavDropdown.Item 
                   onClick={() => setIsExpanded(false)} active={router.pathname === "/history"}>
                  Search History
                  </NavDropdown.Item>
                  </Link>
              </NavDropdown>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      <br />
      <br />
    </>
  );
}