/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "(pages-dir-node)/./components/Layout.js":
/*!******************************!*\
  !*** ./components/Layout.js ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! __barrel_optimize__?names=Container!=!react-bootstrap */ \"(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/cjs/index.js\");\n/* harmony import */ var _MainNav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainNav */ \"(pages-dir-node)/./components/MainNav.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainNav__WEBPACK_IMPORTED_MODULE_1__]);\n_MainNav__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction Layout(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_MainNav__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/Layout.js\",\n                lineNumber: 7,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/Layout.js\",\n                lineNumber: 8,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_barrel_optimize_names_Container_react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {\n                children: props.children\n            }, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/Layout.js\",\n                lineNumber: 9,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/Layout.js\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvTGF5b3V0LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUE0QztBQUNaO0FBRWpCLFNBQVNFLE9BQU9DLEtBQUs7SUFDbEMscUJBQ0U7OzBCQUNFLDhEQUFDRixnREFBT0E7Ozs7OzBCQUNSLDhEQUFDRzs7Ozs7MEJBQ0QsOERBQUNKLHVGQUFTQTswQkFDUEcsTUFBTUUsUUFBUTs7Ozs7OzBCQUVqQiw4REFBQ0Q7Ozs7Ozs7QUFHUCIsInNvdXJjZXMiOlsiL1VzZXJzL2ZhcmloYWFzbGFtaS9Eb2N1bWVudHMvc2VuZWNhL3NlbTQvd2ViNDIyL2Fzc2lnbm1lbnRzL2Fzc2lnbm1lbnQ1L01FVF9NVVNFVU1fQVBQL2NvbXBvbmVudHMvTGF5b3V0LmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJ3JlYWN0LWJvb3RzdHJhcCc7XG5pbXBvcnQgTWFpbk5hdiBmcm9tICcuL01haW5OYXYnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXQocHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPE1haW5OYXYgLz5cbiAgICAgIDxiciAvPlxuICAgICAgPENvbnRhaW5lcj5cbiAgICAgICAge3Byb3BzLmNoaWxkcmVufVxuICAgICAgPC9Db250YWluZXI+XG4gICAgICA8YnIgLz5cbiAgICA8Lz5cbiAgKTtcbn0iXSwibmFtZXMiOlsiQ29udGFpbmVyIiwiTWFpbk5hdiIsIkxheW91dCIsInByb3BzIiwiYnIiLCJjaGlsZHJlbiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/Layout.js\n");

/***/ }),

/***/ "(pages-dir-node)/./components/MainNav.js":
/*!*******************************!*\
  !*** ./components/MainNav.js ***!
  \*******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MainNav)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-bootstrap/Navbar */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/Navbar.js\");\n/* harmony import */ var react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-bootstrap/Nav */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/Nav.js\");\n/* harmony import */ var react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-bootstrap/Form */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/Form.js\");\n/* harmony import */ var react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9__);\n/* harmony import */ var react_bootstrap_FormControl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-bootstrap/FormControl */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/FormControl.js\");\n/* harmony import */ var react_bootstrap_FormControl__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_FormControl__WEBPACK_IMPORTED_MODULE_10__);\n/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-bootstrap/Button */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/Button.js\");\n/* harmony import */ var react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_11__);\n/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-bootstrap/Container */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/Container.js\");\n/* harmony import */ var react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jotai */ \"jotai\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/store */ \"(pages-dir-node)/./store.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/link */ \"(pages-dir-node)/./node_modules/next/link.js\");\n/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ \"(pages-dir-node)/./node_modules/next/router.js\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! react-bootstrap/NavDropdown */ \"(pages-dir-node)/./node_modules/react-bootstrap/cjs/NavDropdown.js\");\n/* harmony import */ var react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_2__, _store__WEBPACK_IMPORTED_MODULE_3__]);\n([jotai__WEBPACK_IMPORTED_MODULE_2__, _store__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\n\n\n\n\n\n\n\n\n\nfunction MainNav() {\n    const [isExpanded, setIsExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);\n    const [searchField, setSearchField] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)('');\n    const [searchHistory, setSearchHistory] = (0,jotai__WEBPACK_IMPORTED_MODULE_2__.useAtom)(_store__WEBPACK_IMPORTED_MODULE_3__.searchHistoryAtom);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();\n    function submitForm(e) {\n        e.preventDefault();\n        if (!searchField.trim()) return;\n        const queryString = `title=true&q=${searchField}`;\n        setSearchHistory((current)=>[\n                ...current,\n                queryString\n            ]);\n        router.push(`/artwork?title=true&q=${searchField}`);\n        setSearchField('');\n        setIsExpanded(false);\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6___default()), {\n                expanded: isExpanded,\n                expand: \"lg\",\n                className: \"navbar navbar-dark bg-primary fixed-top\",\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Container__WEBPACK_IMPORTED_MODULE_7___default()), {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6___default().Brand), {\n                            children: \"Fariha Shajjan\"\n                        }, void 0, false, {\n                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                            lineNumber: 42,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6___default().Toggle), {\n                            \"aria-controls\": \"basic-navbar-nav\",\n                            onClick: ()=>setIsExpanded(!isExpanded)\n                        }, void 0, false, {\n                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                            lineNumber: 43,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Navbar__WEBPACK_IMPORTED_MODULE_6___default().Collapse), {\n                            id: \"basic-navbar-nav\",\n                            children: [\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8___default()), {\n                                    className: \"me-auto\",\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                            href: \"/\",\n                                            passHref: true,\n                                            legacyBehavior: true,\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8___default().Link), {\n                                                onClick: ()=>setIsExpanded(false),\n                                                active: router.pathname === \"/\",\n                                                children: \"Home\"\n                                            }, void 0, false, {\n                                                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                lineNumber: 51,\n                                                columnNumber: 13\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                            lineNumber: 50,\n                                            columnNumber: 13\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                            href: \"/search\",\n                                            passHref: true,\n                                            legacyBehavior: true,\n                                            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8___default().Link), {\n                                                onClick: ()=>setIsExpanded(false),\n                                                active: router.pathname === \"/search\",\n                                                children: \"Advanced Search\"\n                                            }, void 0, false, {\n                                                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                lineNumber: 57,\n                                                columnNumber: 13\n                                            }, this)\n                                        }, void 0, false, {\n                                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                            lineNumber: 56,\n                                            columnNumber: 13\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                    lineNumber: 49,\n                                    columnNumber: 15\n                                }, this),\n                                \"\\xa0\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Form__WEBPACK_IMPORTED_MODULE_9___default()), {\n                                    className: \"d-flex\",\n                                    onSubmit: submitForm,\n                                    children: [\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_FormControl__WEBPACK_IMPORTED_MODULE_10___default()), {\n                                            type: \"search\",\n                                            placeholder: \"Search\",\n                                            className: \"me-2\",\n                                            \"aria-label\": \"Search\",\n                                            value: searchField,\n                                            onChange: (e)=>setSearchField(e.target.value)\n                                        }, void 0, false, {\n                                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                            lineNumber: 65,\n                                            columnNumber: 15\n                                        }, this),\n                                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Button__WEBPACK_IMPORTED_MODULE_11___default()), {\n                                            variant: \"success\",\n                                            type: \"submit\",\n                                            children: \"Search\"\n                                        }, void 0, false, {\n                                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                            lineNumber: 73,\n                                            columnNumber: 15\n                                        }, this)\n                                    ]\n                                }, void 0, true, {\n                                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                    lineNumber: 64,\n                                    columnNumber: 13\n                                }, this),\n                                \"\\xa0\",\n                                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_Nav__WEBPACK_IMPORTED_MODULE_8___default()), {\n                                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12___default()), {\n                                        title: \"User Name\",\n                                        id: \"basic-nav-dropdown\",\n                                        children: [\n                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                                href: \"/favourites\",\n                                                passHref: true,\n                                                legacyBehavior: true,\n                                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12___default().Item), {\n                                                    onClick: ()=>setIsExpanded(false),\n                                                    active: router.pathname === \"/favourites\",\n                                                    children: \"Favourites\"\n                                                }, void 0, false, {\n                                                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                    lineNumber: 80,\n                                                    columnNumber: 19\n                                                }, this)\n                                            }, void 0, false, {\n                                                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                lineNumber: 79,\n                                                columnNumber: 17\n                                            }, this),\n                                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {\n                                                href: \"/history\",\n                                                passHref: true,\n                                                legacyBehavior: true,\n                                                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_bootstrap_NavDropdown__WEBPACK_IMPORTED_MODULE_12___default().Item), {\n                                                    onClick: ()=>setIsExpanded(false),\n                                                    active: router.pathname === \"/history\",\n                                                    children: \"Search History\"\n                                                }, void 0, false, {\n                                                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                    lineNumber: 87,\n                                                    columnNumber: 19\n                                                }, this)\n                                            }, void 0, false, {\n                                                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                                lineNumber: 86,\n                                                columnNumber: 17\n                                            }, this)\n                                        ]\n                                    }, void 0, true, {\n                                        fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                        lineNumber: 78,\n                                        columnNumber: 15\n                                    }, this)\n                                }, void 0, false, {\n                                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                                    lineNumber: 77,\n                                    columnNumber: 13\n                                }, this)\n                            ]\n                        }, void 0, true, {\n                            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                            lineNumber: 48,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, void 0, true, {\n                    fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                    lineNumber: 41,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                lineNumber: 97,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"br\", {}, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/components/MainNav.js\",\n                lineNumber: 98,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL2NvbXBvbmVudHMvTWFpbk5hdi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFpQztBQUNXO0FBQ047QUFDRTtBQUNjO0FBQ1Y7QUFDTTtBQUNsQjtBQUNZO0FBR2Y7QUFDVztBQUNjO0FBSXZDLFNBQVNZO0lBQ3RCLE1BQU0sQ0FBQ0MsWUFBWUMsY0FBYyxHQUFHZCwrQ0FBUUEsQ0FBQztJQUM3QyxNQUFNLENBQUNlLGFBQWFDLGVBQWUsR0FBR2hCLCtDQUFRQSxDQUFDO0lBQy9DLE1BQU0sQ0FBQ2lCLGVBQWVDLGlCQUFpQixHQUFHWCw4Q0FBT0EsQ0FBQ0MscURBQWlCQTtJQUduRSxNQUFNVyxTQUFTVCxzREFBU0E7SUFFeEIsU0FBU1UsV0FBV0MsQ0FBQztRQUNuQkEsRUFBRUMsY0FBYztRQUNoQixJQUFJLENBQUNQLFlBQVlRLElBQUksSUFBSTtRQUN6QixNQUFNQyxjQUFjLENBQUMsYUFBYSxFQUFFVCxhQUFhO1FBQ2pERyxpQkFBaUJPLENBQUFBLFVBQVc7bUJBQUlBO2dCQUFTRDthQUFZO1FBQ3JETCxPQUFPTyxJQUFJLENBQUMsQ0FBQyxzQkFBc0IsRUFBRVgsYUFBYTtRQUNsREMsZUFBZTtRQUNmRixjQUFjO0lBQ2hCO0lBRUEscUJBQ0U7OzBCQUNFLDhEQUFDYiwrREFBTUE7Z0JBQUMwQixVQUFVZDtnQkFBWWUsUUFBTztnQkFBS0MsV0FBVTswQkFHbEQsNEVBQUN2QixrRUFBU0E7O3NDQUNSLDhEQUFDTCxxRUFBWTtzQ0FBQzs7Ozs7O3NDQUNkLDhEQUFDQSxzRUFBYTs0QkFDWitCLGlCQUFjOzRCQUNkQyxTQUFTLElBQU1uQixjQUFjLENBQUNEOzs7Ozs7c0NBR2hDLDhEQUFDWix3RUFBZTs0QkFBQ2tDLElBQUc7OzhDQUNoQiw4REFBQ2pDLDREQUFHQTtvQ0FBQzJCLFdBQVU7O3NEQUNqQiw4REFBQ3BCLGtEQUFJQTs0Q0FBQzJCLE1BQUs7NENBQUlDLFFBQVE7NENBQUNDLGNBQWM7c0RBQ3RDLDRFQUFDcEMsaUVBQVE7Z0RBQUMrQixTQUFTLElBQU1uQixjQUFjO2dEQUFReUIsUUFBUXBCLE9BQU9xQixRQUFRLEtBQUs7MERBQUs7Ozs7Ozs7Ozs7O3NEQUtoRiw4REFBQy9CLGtEQUFJQTs0Q0FBQzJCLE1BQUs7NENBQVVDLFFBQVE7NENBQUNDLGNBQWM7c0RBQzVDLDRFQUFDcEMsaUVBQVE7Z0RBQUMrQixTQUFTLElBQU1uQixjQUFjO2dEQUFReUIsUUFBUXBCLE9BQU9xQixRQUFRLEtBQUs7MERBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQUloRjs4Q0FHTiw4REFBQ3JDLDZEQUFJQTtvQ0FBQzBCLFdBQVU7b0NBQVNZLFVBQVVyQjs7c0RBQ2pDLDhEQUFDaEIscUVBQVdBOzRDQUNWc0MsTUFBSzs0Q0FDTEMsYUFBWTs0Q0FDWmQsV0FBVTs0Q0FDVmUsY0FBVzs0Q0FDWEMsT0FBTzlCOzRDQUNQK0IsVUFBVSxDQUFDekIsSUFBTUwsZUFBZUssRUFBRTBCLE1BQU0sQ0FBQ0YsS0FBSzs7Ozs7O3NEQUVoRCw4REFBQ3hDLGdFQUFNQTs0Q0FBQzJDLFNBQVE7NENBQVVOLE1BQUs7c0RBQVM7Ozs7Ozs7Ozs7OztnQ0FDbkM7OENBR1AsOERBQUN4Qyw0REFBR0E7OENBQ0YsNEVBQUNTLHFFQUFXQTt3Q0FBQ3NDLE9BQU07d0NBQVlkLElBQUc7OzBEQUNoQyw4REFBQzFCLGtEQUFJQTtnREFBQzJCLE1BQUs7Z0RBQWNDLFFBQVE7Z0RBQUNDLGNBQWM7MERBQzlDLDRFQUFDM0IsMEVBQWdCO29EQUNoQnNCLFNBQVMsSUFBTW5CLGNBQWM7b0RBQVF5QixRQUFRcEIsT0FBT3FCLFFBQVEsS0FBSzs4REFBZTs7Ozs7Ozs7Ozs7MERBS25GLDhEQUFDL0Isa0RBQUlBO2dEQUFDMkIsTUFBSztnREFBV0MsUUFBUTtnREFBQ0MsY0FBYzswREFDM0MsNEVBQUMzQiwwRUFBZ0I7b0RBQ2hCc0IsU0FBUyxJQUFNbkIsY0FBYztvREFBUXlCLFFBQVFwQixPQUFPcUIsUUFBUSxLQUFLOzhEQUFZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MEJBUzFGLDhEQUFDVzs7Ozs7MEJBQ0QsOERBQUNBOzs7Ozs7O0FBR1AiLCJzb3VyY2VzIjpbIi9Vc2Vycy9mYXJpaGFhc2xhbWkvRG9jdW1lbnRzL3NlbmVjYS9zZW00L3dlYjQyMi9hc3NpZ25tZW50cy9hc3NpZ25tZW50NS9NRVRfTVVTRVVNX0FQUC9jb21wb25lbnRzL01haW5OYXYuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgTmF2YmFyIGZyb20gJ3JlYWN0LWJvb3RzdHJhcC9OYXZiYXInO1xuaW1wb3J0IE5hdiBmcm9tICdyZWFjdC1ib290c3RyYXAvTmF2JztcbmltcG9ydCBGb3JtIGZyb20gJ3JlYWN0LWJvb3RzdHJhcC9Gb3JtJztcbmltcG9ydCBGb3JtQ29udHJvbCBmcm9tICdyZWFjdC1ib290c3RyYXAvRm9ybUNvbnRyb2wnO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICdyZWFjdC1ib290c3RyYXAvQnV0dG9uJztcbmltcG9ydCBDb250YWluZXIgZnJvbSAncmVhY3QtYm9vdHN0cmFwL0NvbnRhaW5lcic7XG5pbXBvcnQgeyB1c2VBdG9tIH0gZnJvbSAnam90YWknO1xuaW1wb3J0IHsgc2VhcmNoSGlzdG9yeUF0b20gfSBmcm9tICdAL3N0b3JlJztcblxuXG5pbXBvcnQgTGluayBmcm9tICduZXh0L2xpbmsnO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInO1xuaW1wb3J0IE5hdkRyb3Bkb3duIGZyb20gJ3JlYWN0LWJvb3RzdHJhcC9OYXZEcm9wZG93bic7XG5cblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYWluTmF2KCkge1xuICBjb25zdCBbaXNFeHBhbmRlZCwgc2V0SXNFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzZWFyY2hGaWVsZCwgc2V0U2VhcmNoRmllbGRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VhcmNoSGlzdG9yeSwgc2V0U2VhcmNoSGlzdG9yeV0gPSB1c2VBdG9tKHNlYXJjaEhpc3RvcnlBdG9tKTtcblxuICBcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cbiAgZnVuY3Rpb24gc3VibWl0Rm9ybShlKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghc2VhcmNoRmllbGQudHJpbSgpKSByZXR1cm47XG4gICAgY29uc3QgcXVlcnlTdHJpbmcgPSBgdGl0bGU9dHJ1ZSZxPSR7c2VhcmNoRmllbGR9YDtcbiAgICBzZXRTZWFyY2hIaXN0b3J5KGN1cnJlbnQgPT4gWy4uLmN1cnJlbnQsIHF1ZXJ5U3RyaW5nXSk7XG4gICAgcm91dGVyLnB1c2goYC9hcnR3b3JrP3RpdGxlPXRydWUmcT0ke3NlYXJjaEZpZWxkfWApO1xuICAgIHNldFNlYXJjaEZpZWxkKCcnKTtcbiAgICBzZXRJc0V4cGFuZGVkKGZhbHNlKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxOYXZiYXIgZXhwYW5kZWQ9e2lzRXhwYW5kZWR9IGV4cGFuZD1cImxnXCIgY2xhc3NOYW1lPVwibmF2YmFyIG5hdmJhci1kYXJrIGJnLXByaW1hcnkgZml4ZWQtdG9wXCI+XG5cbiAgICAgIFxuICAgICAgICA8Q29udGFpbmVyPlxuICAgICAgICAgIDxOYXZiYXIuQnJhbmQ+RmFyaWhhIFNoYWpqYW48L05hdmJhci5CcmFuZD5cbiAgICAgICAgICA8TmF2YmFyLlRvZ2dsZVxuICAgICAgICAgICAgYXJpYS1jb250cm9scz1cImJhc2ljLW5hdmJhci1uYXZcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZCghaXNFeHBhbmRlZCl9IFxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8TmF2YmFyLkNvbGxhcHNlIGlkPVwiYmFzaWMtbmF2YmFyLW5hdlwiPlxuICAgICAgICAgICAgICA8TmF2IGNsYXNzTmFtZT1cIm1lLWF1dG9cIj5cbiAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCIgcGFzc0hyZWYgbGVnYWN5QmVoYXZpb3I+XG4gICAgICAgICAgICA8TmF2Lkxpbmsgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9IGFjdGl2ZT17cm91dGVyLnBhdGhuYW1lID09PSBcIi9cIn0+XG4gICAgICAgICAgICAgSG9tZVxuICAgICAgICAgICAgPC9OYXYuTGluaz5cbiAgICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9zZWFyY2hcIiBwYXNzSHJlZiBsZWdhY3lCZWhhdmlvcj5cbiAgICAgICAgICAgIDxOYXYuTGluayBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKGZhbHNlKX0gYWN0aXZlPXtyb3V0ZXIucGF0aG5hbWUgPT09IFwiL3NlYXJjaFwifT5cbiAgICAgICAgICAgIEFkdmFuY2VkIFNlYXJjaFxuICAgICAgICAgICAgPC9OYXYuTGluaz5cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgIDwvTmF2PlxuICAgICAgICAgICAgJm5ic3A7XG5cbiAgICAgICAgICAgIDxGb3JtIGNsYXNzTmFtZT1cImQtZmxleFwiIG9uU3VibWl0PXtzdWJtaXRGb3JtfT5cbiAgICAgICAgICAgICAgPEZvcm1Db250cm9sXG4gICAgICAgICAgICAgICAgdHlwZT1cInNlYXJjaFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2hcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1lLTJcIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2hcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hGaWVsZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaEZpZWxkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwic3VjY2Vzc1wiIHR5cGU9XCJzdWJtaXRcIj5TZWFyY2g8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvRm9ybT5cbiAgICAgICAgICAgICZuYnNwO1xuICAgICAgICAgICAgIHsvKiBVc2VyIGRyb3Bkb3duIChGYXZvdXJpdGVzKSAqL31cbiAgICAgICAgICAgIDxOYXY+XG4gICAgICAgICAgICAgIDxOYXZEcm9wZG93biB0aXRsZT1cIlVzZXIgTmFtZVwiIGlkPVwiYmFzaWMtbmF2LWRyb3Bkb3duXCI+XG4gICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIi9mYXZvdXJpdGVzXCIgcGFzc0hyZWYgbGVnYWN5QmVoYXZpb3I+XG4gICAgICAgICAgICAgICAgICA8TmF2RHJvcGRvd24uSXRlbSBcbiAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0V4cGFuZGVkKGZhbHNlKX0gYWN0aXZlPXtyb3V0ZXIucGF0aG5hbWUgPT09IFwiL2Zhdm91cml0ZXNcIn0+XG4gICAgICAgICAgICAgICAgICAgIEZhdm91cml0ZXNcbiAgICAgICAgICAgICAgICAgIDwvTmF2RHJvcGRvd24uSXRlbT5cbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvaGlzdG9yeVwiIHBhc3NIcmVmIGxlZ2FjeUJlaGF2aW9yPlxuICAgICAgICAgICAgICAgICAgPE5hdkRyb3Bkb3duLkl0ZW0gXG4gICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNFeHBhbmRlZChmYWxzZSl9IGFjdGl2ZT17cm91dGVyLnBhdGhuYW1lID09PSBcIi9oaXN0b3J5XCJ9PlxuICAgICAgICAgICAgICAgICAgU2VhcmNoIEhpc3RvcnlcbiAgICAgICAgICAgICAgICAgIDwvTmF2RHJvcGRvd24uSXRlbT5cbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgPC9OYXZEcm9wZG93bj5cbiAgICAgICAgICAgIDwvTmF2PlxuICAgICAgICAgIDwvTmF2YmFyLkNvbGxhcHNlPlxuICAgICAgICA8L0NvbnRhaW5lcj5cbiAgICAgIDwvTmF2YmFyPlxuICAgICAgPGJyIC8+XG4gICAgICA8YnIgLz5cbiAgICA8Lz5cbiAgKTtcbn0iXSwibmFtZXMiOlsidXNlU3RhdGUiLCJOYXZiYXIiLCJOYXYiLCJGb3JtIiwiRm9ybUNvbnRyb2wiLCJCdXR0b24iLCJDb250YWluZXIiLCJ1c2VBdG9tIiwic2VhcmNoSGlzdG9yeUF0b20iLCJMaW5rIiwidXNlUm91dGVyIiwiTmF2RHJvcGRvd24iLCJNYWluTmF2IiwiaXNFeHBhbmRlZCIsInNldElzRXhwYW5kZWQiLCJzZWFyY2hGaWVsZCIsInNldFNlYXJjaEZpZWxkIiwic2VhcmNoSGlzdG9yeSIsInNldFNlYXJjaEhpc3RvcnkiLCJyb3V0ZXIiLCJzdWJtaXRGb3JtIiwiZSIsInByZXZlbnREZWZhdWx0IiwidHJpbSIsInF1ZXJ5U3RyaW5nIiwiY3VycmVudCIsInB1c2giLCJleHBhbmRlZCIsImV4cGFuZCIsImNsYXNzTmFtZSIsIkJyYW5kIiwiVG9nZ2xlIiwiYXJpYS1jb250cm9scyIsIm9uQ2xpY2siLCJDb2xsYXBzZSIsImlkIiwiaHJlZiIsInBhc3NIcmVmIiwibGVnYWN5QmVoYXZpb3IiLCJhY3RpdmUiLCJwYXRobmFtZSIsIm9uU3VibWl0IiwidHlwZSIsInBsYWNlaG9sZGVyIiwiYXJpYS1sYWJlbCIsInZhbHVlIiwib25DaGFuZ2UiLCJ0YXJnZXQiLCJ2YXJpYW50IiwidGl0bGUiLCJJdGVtIiwiYnIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./components/MainNav.js\n");

/***/ }),

/***/ "(pages-dir-node)/./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/styles/bootstrap.min.css */ \"(pages-dir-node)/./styles/bootstrap.min.css\");\n/* harmony import */ var _styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_bootstrap_min_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! swr */ \"swr\");\n/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @/components/Layout */ \"(pages-dir-node)/./components/Layout.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swr__WEBPACK_IMPORTED_MODULE_2__, _components_Layout__WEBPACK_IMPORTED_MODULE_3__]);\n([swr__WEBPACK_IMPORTED_MODULE_2__, _components_Layout__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);\n\n\n\n\nconst fetcher = async (url)=>{\n    const res = await fetch(url);\n    // If the status code is not in the range 200-299,\n    // we still try to parse and throw it.\n    if (!res.ok) {\n        const error = new Error('An error occurred while fetching the data.');\n        // Attach extra info to the error object.\n        error.info = await res.json();\n        error.status = res.status;\n        throw error;\n    }\n    return res.json();\n};\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(swr__WEBPACK_IMPORTED_MODULE_2__.SWRConfig, {\n        value: {\n            fetcher\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/pages/_app.js\",\n                lineNumber: 23,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/pages/_app.js\",\n            lineNumber: 22,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/farihaaslami/Documents/seneca/sem4/web422/assignments/assignment5/MET_MUSEUM_APP/pages/_app.js\",\n        lineNumber: 21,\n        columnNumber: 5\n    }, this);\n}\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3BhZ2VzL19hcHAuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBb0M7QUFDSjtBQUNTO0FBRXpDLE1BQU1FLFVBQVUsT0FBT0M7SUFDckIsTUFBTUMsTUFBTSxNQUFNQyxNQUFNRjtJQUN4QixrREFBa0Q7SUFDbEQsc0NBQXNDO0lBQ3RDLElBQUksQ0FBQ0MsSUFBSUUsRUFBRSxFQUFFO1FBQ1gsTUFBTUMsUUFBUSxJQUFJQyxNQUFNO1FBQ3hCLHlDQUF5QztRQUN6Q0QsTUFBTUUsSUFBSSxHQUFHLE1BQU1MLElBQUlNLElBQUk7UUFDM0JILE1BQU1JLE1BQU0sR0FBR1AsSUFBSU8sTUFBTTtRQUN6QixNQUFNSjtJQUNSO0lBQ0EsT0FBT0gsSUFBSU0sSUFBSTtBQUNqQjtBQUVlLFNBQVNFLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQ0UsOERBQUNkLDBDQUFTQTtRQUFDZSxPQUFPO1lBQUViO1FBQVE7a0JBQzFCLDRFQUFDRCwwREFBTUE7c0JBQ0wsNEVBQUNZO2dCQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJaEMiLCJzb3VyY2VzIjpbIi9Vc2Vycy9mYXJpaGFhc2xhbWkvRG9jdW1lbnRzL3NlbmVjYS9zZW00L3dlYjQyMi9hc3NpZ25tZW50cy9hc3NpZ25tZW50NS9NRVRfTVVTRVVNX0FQUC9wYWdlcy9fYXBwLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnQC9zdHlsZXMvYm9vdHN0cmFwLm1pbi5jc3MnO1xuaW1wb3J0IHsgU1dSQ29uZmlnIH0gZnJvbSAnc3dyJztcbmltcG9ydCBMYXlvdXQgZnJvbSAnQC9jb21wb25lbnRzL0xheW91dCc7XG5cbmNvbnN0IGZldGNoZXIgPSBhc3luYyAodXJsKSA9PiB7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKHVybClcbiAgLy8gSWYgdGhlIHN0YXR1cyBjb2RlIGlzIG5vdCBpbiB0aGUgcmFuZ2UgMjAwLTI5OSxcbiAgLy8gd2Ugc3RpbGwgdHJ5IHRvIHBhcnNlIGFuZCB0aHJvdyBpdC5cbiAgaWYgKCFyZXMub2spIHtcbiAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcignQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgZmV0Y2hpbmcgdGhlIGRhdGEuJylcbiAgICAvLyBBdHRhY2ggZXh0cmEgaW5mbyB0byB0aGUgZXJyb3Igb2JqZWN0LlxuICAgIGVycm9yLmluZm8gPSBhd2FpdCByZXMuanNvbigpXG4gICAgZXJyb3Iuc3RhdHVzID0gcmVzLnN0YXR1c1xuICAgIHRocm93IGVycm9yXG4gIH1cbiAgcmV0dXJuIHJlcy5qc29uKClcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxTV1JDb25maWcgdmFsdWU9e3sgZmV0Y2hlciB9fT5cbiAgICAgIDxMYXlvdXQ+XG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgIDwvTGF5b3V0PlxuICAgIDwvU1dSQ29uZmlnPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIlNXUkNvbmZpZyIsIkxheW91dCIsImZldGNoZXIiLCJ1cmwiLCJyZXMiLCJmZXRjaCIsIm9rIiwiZXJyb3IiLCJFcnJvciIsImluZm8iLCJqc29uIiwic3RhdHVzIiwiQXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidmFsdWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(pages-dir-node)/./pages/_app.js\n");

/***/ }),

/***/ "(pages-dir-node)/./store.js":
/*!******************!*\
  !*** ./store.js ***!
  \******************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   favouritesAtom: () => (/* binding */ favouritesAtom),\n/* harmony export */   searchHistoryAtom: () => (/* binding */ searchHistoryAtom)\n/* harmony export */ });\n/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! jotai */ \"jotai\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([jotai__WEBPACK_IMPORTED_MODULE_0__]);\njotai__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\nconst favouritesAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\nconst searchHistoryAtom = (0,jotai__WEBPACK_IMPORTED_MODULE_0__.atom)([]);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHBhZ2VzLWRpci1ub2RlKS8uL3N0b3JlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUEyQjtBQUNwQixNQUFNQyxpQkFBaUJELDJDQUFJQSxDQUFDLEVBQUUsRUFBQztBQUMvQixNQUFNRSxvQkFBb0JGLDJDQUFJQSxDQUFDLEVBQUUsRUFBRSIsInNvdXJjZXMiOlsiL1VzZXJzL2ZhcmloYWFzbGFtaS9Eb2N1bWVudHMvc2VuZWNhL3NlbTQvd2ViNDIyL2Fzc2lnbm1lbnRzL2Fzc2lnbm1lbnQ1L01FVF9NVVNFVU1fQVBQL3N0b3JlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7YXRvbX0gZnJvbSAnam90YWknO1xuZXhwb3J0IGNvbnN0IGZhdm91cml0ZXNBdG9tID0gYXRvbShbXSlcbmV4cG9ydCBjb25zdCBzZWFyY2hIaXN0b3J5QXRvbSA9IGF0b20oW10pOyJdLCJuYW1lcyI6WyJhdG9tIiwiZmF2b3VyaXRlc0F0b20iLCJzZWFyY2hIaXN0b3J5QXRvbSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(pages-dir-node)/./store.js\n");

/***/ }),

/***/ "(pages-dir-node)/./styles/bootstrap.min.css":
/*!**********************************!*\
  !*** ./styles/bootstrap.min.css ***!
  \**********************************/
/***/ (() => {



/***/ }),

/***/ "(pages-dir-node)/__barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/cjs/index.js":
/*!*****************************************************************************************!*\
  !*** __barrel_optimize__?names=Container!=!./node_modules/react-bootstrap/cjs/index.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Users_farihaaslami_Documents_seneca_sem4_web422_assignments_assignment5_MET_MUSEUM_APP_node_modules_react_bootstrap_cjs_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/react-bootstrap/cjs/index.js */ "(pages-dir-node)/./node_modules/react-bootstrap/cjs/index.js");
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _Users_farihaaslami_Documents_seneca_sem4_web422_assignments_assignment5_MET_MUSEUM_APP_node_modules_react_bootstrap_cjs_index_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _Users_farihaaslami_Documents_seneca_sem4_web422_assignments_assignment5_MET_MUSEUM_APP_node_modules_react_bootstrap_cjs_index_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);


/***/ }),

/***/ "@restart/hooks/useBreakpoint":
/*!***********************************************!*\
  !*** external "@restart/hooks/useBreakpoint" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useBreakpoint");

/***/ }),

/***/ "@restart/hooks/useCallbackRef":
/*!************************************************!*\
  !*** external "@restart/hooks/useCallbackRef" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useCallbackRef");

/***/ }),

/***/ "@restart/hooks/useCommittedRef":
/*!*************************************************!*\
  !*** external "@restart/hooks/useCommittedRef" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useCommittedRef");

/***/ }),

/***/ "@restart/hooks/useEventCallback":
/*!**************************************************!*\
  !*** external "@restart/hooks/useEventCallback" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useEventCallback");

/***/ }),

/***/ "@restart/hooks/useIsomorphicEffect":
/*!*****************************************************!*\
  !*** external "@restart/hooks/useIsomorphicEffect" ***!
  \*****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useIsomorphicEffect");

/***/ }),

/***/ "@restart/hooks/useMergedRefs":
/*!***********************************************!*\
  !*** external "@restart/hooks/useMergedRefs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useMergedRefs");

/***/ }),

/***/ "@restart/hooks/useTimeout":
/*!********************************************!*\
  !*** external "@restart/hooks/useTimeout" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useTimeout");

/***/ }),

/***/ "@restart/hooks/useUpdateEffect":
/*!*************************************************!*\
  !*** external "@restart/hooks/useUpdateEffect" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useUpdateEffect");

/***/ }),

/***/ "@restart/hooks/useWillUnmount":
/*!************************************************!*\
  !*** external "@restart/hooks/useWillUnmount" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/hooks/useWillUnmount");

/***/ }),

/***/ "@restart/ui/Anchor":
/*!*************************************!*\
  !*** external "@restart/ui/Anchor" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Anchor");

/***/ }),

/***/ "@restart/ui/Button":
/*!*************************************!*\
  !*** external "@restart/ui/Button" ***!
  \*************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Button");

/***/ }),

/***/ "@restart/ui/Dropdown":
/*!***************************************!*\
  !*** external "@restart/ui/Dropdown" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Dropdown");

/***/ }),

/***/ "@restart/ui/DropdownContext":
/*!**********************************************!*\
  !*** external "@restart/ui/DropdownContext" ***!
  \**********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownContext");

/***/ }),

/***/ "@restart/ui/DropdownItem":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownItem" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownItem");

/***/ }),

/***/ "@restart/ui/DropdownMenu":
/*!*******************************************!*\
  !*** external "@restart/ui/DropdownMenu" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownMenu");

/***/ }),

/***/ "@restart/ui/DropdownToggle":
/*!*********************************************!*\
  !*** external "@restart/ui/DropdownToggle" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/DropdownToggle");

/***/ }),

/***/ "@restart/ui/Modal":
/*!************************************!*\
  !*** external "@restart/ui/Modal" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Modal");

/***/ }),

/***/ "@restart/ui/ModalManager":
/*!*******************************************!*\
  !*** external "@restart/ui/ModalManager" ***!
  \*******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ModalManager");

/***/ }),

/***/ "@restart/ui/Nav":
/*!**********************************!*\
  !*** external "@restart/ui/Nav" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Nav");

/***/ }),

/***/ "@restart/ui/NavItem":
/*!**************************************!*\
  !*** external "@restart/ui/NavItem" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NavItem");

/***/ }),

/***/ "@restart/ui/NoopTransition":
/*!*********************************************!*\
  !*** external "@restart/ui/NoopTransition" ***!
  \*********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/NoopTransition");

/***/ }),

/***/ "@restart/ui/Overlay":
/*!**************************************!*\
  !*** external "@restart/ui/Overlay" ***!
  \**************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Overlay");

/***/ }),

/***/ "@restart/ui/SelectableContext":
/*!************************************************!*\
  !*** external "@restart/ui/SelectableContext" ***!
  \************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/SelectableContext");

/***/ }),

/***/ "@restart/ui/TabContext":
/*!*****************************************!*\
  !*** external "@restart/ui/TabContext" ***!
  \*****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/TabContext");

/***/ }),

/***/ "@restart/ui/TabPanel":
/*!***************************************!*\
  !*** external "@restart/ui/TabPanel" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/TabPanel");

/***/ }),

/***/ "@restart/ui/Tabs":
/*!***********************************!*\
  !*** external "@restart/ui/Tabs" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/Tabs");

/***/ }),

/***/ "@restart/ui/ssr":
/*!**********************************!*\
  !*** external "@restart/ui/ssr" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/ssr");

/***/ }),

/***/ "@restart/ui/utils":
/*!************************************!*\
  !*** external "@restart/ui/utils" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@restart/ui/utils");

/***/ }),

/***/ "classnames":
/*!*****************************!*\
  !*** external "classnames" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ "dom-helpers/addClass":
/*!***************************************!*\
  !*** external "dom-helpers/addClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addClass");

/***/ }),

/***/ "dom-helpers/addEventListener":
/*!***********************************************!*\
  !*** external "dom-helpers/addEventListener" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/addEventListener");

/***/ }),

/***/ "dom-helpers/canUseDOM":
/*!****************************************!*\
  !*** external "dom-helpers/canUseDOM" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/canUseDOM");

/***/ }),

/***/ "dom-helpers/contains":
/*!***************************************!*\
  !*** external "dom-helpers/contains" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/contains");

/***/ }),

/***/ "dom-helpers/css":
/*!**********************************!*\
  !*** external "dom-helpers/css" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/css");

/***/ }),

/***/ "dom-helpers/hasClass":
/*!***************************************!*\
  !*** external "dom-helpers/hasClass" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/hasClass");

/***/ }),

/***/ "dom-helpers/ownerDocument":
/*!********************************************!*\
  !*** external "dom-helpers/ownerDocument" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/ownerDocument");

/***/ }),

/***/ "dom-helpers/querySelectorAll":
/*!***********************************************!*\
  !*** external "dom-helpers/querySelectorAll" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/querySelectorAll");

/***/ }),

/***/ "dom-helpers/removeClass":
/*!******************************************!*\
  !*** external "dom-helpers/removeClass" ***!
  \******************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeClass");

/***/ }),

/***/ "dom-helpers/removeEventListener":
/*!**************************************************!*\
  !*** external "dom-helpers/removeEventListener" ***!
  \**************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/removeEventListener");

/***/ }),

/***/ "dom-helpers/scrollbarSize":
/*!********************************************!*\
  !*** external "dom-helpers/scrollbarSize" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/scrollbarSize");

/***/ }),

/***/ "dom-helpers/transitionEnd":
/*!********************************************!*\
  !*** external "dom-helpers/transitionEnd" ***!
  \********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("dom-helpers/transitionEnd");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "invariant":
/*!****************************!*\
  !*** external "invariant" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("invariant");

/***/ }),

/***/ "jotai":
/*!************************!*\
  !*** external "jotai" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = import("jotai");;

/***/ }),

/***/ "next/dist/compiled/next-server/pages.runtime.dev.js":
/*!**********************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages.runtime.dev.js" ***!
  \**********************************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/next-server/pages.runtime.dev.js");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-dom":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ "react-transition-group/Transition":
/*!****************************************************!*\
  !*** external "react-transition-group/Transition" ***!
  \****************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-transition-group/Transition");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "swr":
/*!**********************!*\
  !*** external "swr" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ }),

/***/ "uncontrollable":
/*!*********************************!*\
  !*** external "uncontrollable" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("uncontrollable");

/***/ }),

/***/ "warning":
/*!**************************!*\
  !*** external "warning" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("warning");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@swc","vendor-chunks/react-bootstrap","vendor-chunks/@babel"], () => (__webpack_exec__("(pages-dir-node)/./pages/_app.js")));
module.exports = __webpack_exports__;

})();